<?php
if (!defined('ABSPATH')) {
    exit;
}

class PouchCare_System_Status
{
    public static function render(): void
    {
        if (!PouchCare_Security::can_manage()) {
            wp_die('Forbidden');
        }

        global $wp_version;

        $php = phpversion() ?: 'Unknown';
        $theme = wp_get_theme();
        $is_multisite = is_multisite() ? 'Yes' : 'No';

        $checks = [
            ['label' => 'WordPress Version', 'value' => (string) $wp_version],
            ['label' => 'PHP Version', 'value' => (string) $php],
            ['label' => 'Multisite', 'value' => $is_multisite],
            ['label' => 'Active Theme', 'value' => (string) $theme->get('Name')],
            ['label' => 'PouchCare Theme Active', 'value' => ($theme->get_stylesheet() === 'pouchcare') ? 'Yes' : 'No'],
            ['label' => 'Plugin Version', 'value' => POUCHCARE_BUILDER_VERSION],
        ];

        echo '<div class="wrap"><h1>PouchCare System Status</h1>';
        echo '<table class="widefat striped"><thead><tr><th>Check</th><th>Value</th></tr></thead><tbody>';

        foreach ($checks as $check) {
            echo '<tr><td>' . esc_html($check['label']) . '</td><td>' . esc_html($check['value']) . '</td></tr>';
        }

        echo '</tbody></table></div>';
    }
}

