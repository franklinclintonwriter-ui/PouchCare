<?php
if (!defined('ABSPATH')) {
    exit;
}

class PouchCare_Licensing
{
    public static function init(): void
    {
        if (!defined('POUCHCARE_LICENSE_CHANNEL')) {
            define('POUCHCARE_LICENSE_CHANNEL', 'community');
        }
    }
}
