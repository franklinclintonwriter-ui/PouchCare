<?php
if (!defined('ABSPATH')) {
    exit;
}

class PouchCare_Updater
{
    public static function init(): void
    {
        add_filter('site_transient_update_plugins', [self::class, 'inject_update_metadata']);
    }

    public static function inject_update_metadata($transient)
    {
        return $transient;
    }
}
