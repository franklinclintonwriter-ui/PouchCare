<?php
if (!defined('ABSPATH')) {
    exit;
}

class PouchCare_Security
{
    public static function init(): void
    {
        // Reserved for additional hardening hooks.
    }

    public static function can_manage(): bool
    {
        return current_user_can('manage_options');
    }
}
