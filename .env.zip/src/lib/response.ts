import type { Response } from 'express'

export function ok<T>(res: Response, data: T, meta?: object) {
  return res.json({ success: true, data, ...(meta && { meta }) })
}
export function created<T>(res: Response, data: T) {
  return res.status(201).json({ success: true, data })
}
export function noContent(res: Response) {
  return res.status(204).send()
}
export function paginated<T>(res: Response, data: T[], meta: { total: number; page: number; limit: number; totalPages: number }) {
  return res.json({ success: true, data, meta })
}
export function err(res: Response, message: string, code?: string, status = 400) {
  return res.status(status).json({ success: false, error: message, ...(code && { code }) })
}
export const badRequest   = (res: Response, msg = 'Bad request')          => err(res, msg, 'BAD_REQUEST', 400)
export const unauthorized = (res: Response, msg = 'Unauthorized')         => err(res, msg, 'UNAUTHORIZED', 401)
export const forbidden    = (res: Response, msg = 'Forbidden')            => err(res, msg, 'FORBIDDEN', 403)
export const notFound     = (res: Response, resource = 'Resource')        => err(res, `${resource} not found`, 'NOT_FOUND', 404)
export const conflict     = (res: Response, msg = 'Conflict')             => err(res, msg, 'CONFLICT', 409)
// Accept unknown for catch(err) blocks
export const serverError  = (res: Response, _err?: unknown) => {
  const msg = _err instanceof Error ? _err.message : 'Internal server error'
  return err(res, msg, 'SERVER_ERROR', 500)
}
