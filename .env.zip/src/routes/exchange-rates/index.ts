import { Router } from 'express'
import { z } from 'zod'
import prisma from '@/lib/prisma'
import { authenticate, isOps } from '@/middleware/auth'
import { validate } from '@/middleware/validate'
import { getPaginationParams, buildMeta } from '@/lib/pagination'
import { ok, created, notFound, serverError } from '@/lib/response'

const router = Router()
router.use(authenticate, isOps)

const exchangeRateSchema = z.object({
  usdToBdt:      z.number().positive(),
  usdToAed:      z.number().positive().optional(),
  bdtToAed:      z.number().positive().optional(),
  effectiveDate: z.string().min(1),
  notes:         z.string().optional(),
})

router.get('/', async (req, res) => {
  try {
    const { page, limit, skip } = getPaginationParams(req.query as any)
    const [items, total] = await Promise.all([
      prisma.exchangeRate.findMany({ skip, take: limit, orderBy: { effectiveDate: 'desc' } }),
      prisma.exchangeRate.count(),
    ])
    return ok(res, items, buildMeta(total, page, limit))
  } catch (err) { return serverError(res, err) }
})

router.get('/latest', async (_req, res) => {
  try {
    const latest = await prisma.exchangeRate.findFirst({ orderBy: { effectiveDate: 'desc' } })
    if (!latest) return notFound(res, 'Exchange rate')
    return ok(res, latest)
  } catch (err) { return serverError(res, err) }
})

router.get('/:id', async (req, res) => {
  try {
    const item = await prisma.exchangeRate.findUnique({ where: { id: req.params.id } })
    if (!item) return notFound(res, 'Exchange rate')
    return ok(res, item)
  } catch (err) { return serverError(res, err) }
})

router.post('/', validate(exchangeRateSchema), async (req, res) => {
  try {
    const item = await prisma.exchangeRate.create({
      data: { ...req.body, effectiveDate: new Date(req.body.effectiveDate) },
    })
    return created(res, item)
  } catch (err) { return serverError(res, err) }
})

router.put('/:id', validate(exchangeRateSchema.partial()), async (req, res) => {
  try {
    const item = await prisma.exchangeRate.update({
      where: { id: req.params.id },
      data: { ...req.body, ...(req.body.effectiveDate !== undefined && { effectiveDate: new Date(req.body.effectiveDate) }) },
    })
    return ok(res, item)
  } catch (err) { return serverError(res, err) }
})

router.delete('/:id', async (req, res) => {
  try {
    await prisma.exchangeRate.delete({ where: { id: req.params.id } })
    return ok(res, { message: 'Exchange rate deleted' })
  } catch (err) { return serverError(res, err) }
})

export default router
