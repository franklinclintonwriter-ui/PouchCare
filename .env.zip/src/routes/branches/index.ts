import { Router } from 'express'
import { z } from 'zod'
import prisma from '@/lib/prisma'
import { authenticate, isOps } from '@/middleware/auth'
import { validate } from '@/middleware/validate'
import { getPaginationParams, buildMeta } from '@/lib/pagination'
import { ok, created, notFound, serverError } from '@/lib/response'

const router = Router()
router.use(authenticate, isOps)

const branchSchema = z.object({
  name:            z.string().min(2),
  country:         z.string().optional(),
  city:            z.string().optional(),
  type:            z.string().optional(),
  status:          z.string().optional(),
  branchManager:   z.string().optional(),
  staffCount:      z.number().int().optional(),
  email:           z.string().email().optional(),
  phone:           z.string().optional(),
  address:         z.string().optional(),
  establishedDate: z.string().optional(),
  notes:           z.string().optional(),
})

router.get('/', async (req, res) => {
  try {
    const { page, limit, skip } = getPaginationParams(req.query as any)
    const q = String(req.query.q ?? '')
    const status = String(req.query.status ?? '')

    const where: any = {}
    if (q) where.name = { contains: q, mode: 'insensitive' }
    if (status) where.status = status

    const [items, total] = await Promise.all([
      prisma.branch.findMany({ where, skip, take: limit, orderBy: { createdAt: 'desc' } }),
      prisma.branch.count({ where }),
    ])
    return ok(res, items, buildMeta(total, page, limit))
  } catch (err) { return serverError(res, err) }
})

router.get('/:id', async (req, res) => {
  try {
    const branch = await prisma.branch.findUnique({ where: { id: req.params.id } })
    if (!branch) return notFound(res, 'Branch')
    return ok(res, branch)
  } catch (err) { return serverError(res, err) }
})

router.post('/', validate(branchSchema), async (req, res) => {
  try {
    const establishedDate = req.body.establishedDate ? new Date(req.body.establishedDate) : undefined
    const branch = await prisma.branch.create({ data: { ...req.body, establishedDate } })
    return created(res, branch)
  } catch (err) { return serverError(res, err) }
})

router.put('/:id', validate(branchSchema.partial()), async (req, res) => {
  try {
    const establishedDate = req.body.establishedDate ? new Date(req.body.establishedDate) : undefined
    const branch = await prisma.branch.update({
      where: { id: req.params.id },
      data: { ...req.body, ...(req.body.establishedDate !== undefined && { establishedDate }) },
    })
    return ok(res, branch)
  } catch (err) { return serverError(res, err) }
})

router.delete('/:id', async (req, res) => {
  try {
    await prisma.branch.delete({ where: { id: req.params.id } })
    return ok(res, { message: 'Branch deleted' })
  } catch (err) { return serverError(res, err) }
})

export default router
