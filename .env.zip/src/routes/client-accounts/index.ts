import { Router } from 'express'
import { z } from 'zod'
import prisma from '@/lib/prisma'
import { authenticate, isOps } from '@/middleware/auth'
import { validate } from '@/middleware/validate'
import { getPaginationParams, buildMeta } from '@/lib/pagination'
import { ok, created, notFound, serverError } from '@/lib/response'

const router = Router()
router.use(authenticate, isOps)

const clientAccountSchema = z.object({
  clientName:      z.string().min(2),
  email:           z.string().email(),
  phone:           z.string().optional(),
  whatsapp:        z.string().optional(),
  country:         z.string().optional(),
  status:          z.string().optional(),
  totalSpentUsd:   z.number().optional(),
  totalOrders:     z.number().int().optional(),
  firstOrderDate:  z.string().optional(),
  lastOrderDate:   z.string().optional(),
  assignedManager: z.string().optional(),
  source:          z.string().optional(),
  linkedinUrl:     z.string().optional(),
  notes:           z.string().optional(),
})

router.get('/', async (req, res) => {
  try {
    const { page, limit, skip } = getPaginationParams(req.query as any)
    const q = String(req.query.q ?? '')
    const status = String(req.query.status ?? '')

    const where: any = {}
    if (status) where.status = status
    if (q) where.OR = [
      { clientName: { contains: q, mode: 'insensitive' } },
      { email: { contains: q, mode: 'insensitive' } },
    ]

    const [items, total] = await Promise.all([
      prisma.clientAccount.findMany({ where, skip, take: limit, orderBy: { createdAt: 'desc' } }),
      prisma.clientAccount.count({ where }),
    ])
    return ok(res, items, buildMeta(total, page, limit))
  } catch (err) { return serverError(res, err) }
})

router.get('/:id', async (req, res) => {
  try {
    const item = await prisma.clientAccount.findUnique({ where: { id: req.params.id } })
    if (!item) return notFound(res, 'Client account')
    return ok(res, item)
  } catch (err) { return serverError(res, err) }
})

router.post('/', validate(clientAccountSchema), async (req, res) => {
  try {
    const firstOrderDate = req.body.firstOrderDate ? new Date(req.body.firstOrderDate) : undefined
    const lastOrderDate = req.body.lastOrderDate ? new Date(req.body.lastOrderDate) : undefined
    const item = await prisma.clientAccount.create({
      data: { ...req.body, firstOrderDate, lastOrderDate },
    })
    return created(res, item)
  } catch (err) { return serverError(res, err) }
})

router.put('/:id', validate(clientAccountSchema.partial()), async (req, res) => {
  try {
    const firstOrderDate = req.body.firstOrderDate ? new Date(req.body.firstOrderDate) : undefined
    const lastOrderDate = req.body.lastOrderDate ? new Date(req.body.lastOrderDate) : undefined
    const item = await prisma.clientAccount.update({
      where: { id: req.params.id },
      data: {
        ...req.body,
        ...(req.body.firstOrderDate !== undefined && { firstOrderDate }),
        ...(req.body.lastOrderDate !== undefined && { lastOrderDate }),
      },
    })
    return ok(res, item)
  } catch (err) { return serverError(res, err) }
})

router.delete('/:id', async (req, res) => {
  try {
    await prisma.clientAccount.delete({ where: { id: req.params.id } })
    return ok(res, { message: 'Client account deleted' })
  } catch (err) { return serverError(res, err) }
})

export default router
