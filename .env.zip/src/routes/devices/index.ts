import { Router } from 'express'
import { z } from 'zod'
import prisma from '@/lib/prisma'
import { authenticate, isOps } from '@/middleware/auth'
import { validate } from '@/middleware/validate'
import { getPaginationParams, buildMeta } from '@/lib/pagination'
import { ok, created, notFound, serverError } from '@/lib/response'

const router = Router()
router.use(authenticate, isOps)

const deviceSchema = z.object({
  staffMemberId:  z.string().min(1),
  deviceName:     z.string().min(2),
  deviceType:     z.string().optional(),
  ipAddress:      z.string().optional(),
  macAddress:     z.string().optional(),
  os:             z.string().optional(),
  status:         z.string().optional(),
  systemRole:     z.string().optional(),
  branch:         z.string().optional(),
  registeredDate: z.string().optional(),
  lastActive:     z.string().optional(),
  notes:          z.string().optional(),
})

router.get('/', async (req, res) => {
  try {
    const { page, limit, skip } = getPaginationParams(req.query as any)
    const staffMemberId = String(req.query.staffMemberId ?? '')
    const status = String(req.query.status ?? '')

    const where: any = {}
    if (staffMemberId) where.staffMemberId = staffMemberId
    if (status) where.status = status

    const [items, total] = await Promise.all([
      prisma.device.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: { staffMember: { select: { id: true, name: true } } },
      }),
      prisma.device.count({ where }),
    ])
    return ok(res, items, buildMeta(total, page, limit))
  } catch (err) { return serverError(res, err) }
})

router.get('/:id', async (req, res) => {
  try {
    const device = await prisma.device.findUnique({
      where: { id: req.params.id },
      include: { staffMember: { select: { id: true, name: true } } },
    })
    if (!device) return notFound(res, 'Device')
    return ok(res, device)
  } catch (err) { return serverError(res, err) }
})

router.post('/', validate(deviceSchema), async (req, res) => {
  try {
    const registeredDate = req.body.registeredDate ? new Date(req.body.registeredDate) : undefined
    const lastActive = req.body.lastActive ? new Date(req.body.lastActive) : undefined
    const device = await prisma.device.create({
      data: {
        ...req.body,
        registeredDate,
        lastActive,
      },
    })
    return created(res, device)
  } catch (err) { return serverError(res, err) }
})

router.put('/:id', validate(deviceSchema.partial()), async (req, res) => {
  try {
    const registeredDate = req.body.registeredDate ? new Date(req.body.registeredDate) : undefined
    const lastActive = req.body.lastActive ? new Date(req.body.lastActive) : undefined
    const device = await prisma.device.update({
      where: { id: req.params.id },
      data: {
        ...req.body,
        ...(req.body.registeredDate !== undefined && { registeredDate }),
        ...(req.body.lastActive !== undefined && { lastActive }),
      },
    })
    return ok(res, device)
  } catch (err) { return serverError(res, err) }
})

router.delete('/:id', async (req, res) => {
  try {
    await prisma.device.delete({ where: { id: req.params.id } })
    return ok(res, { message: 'Device deleted' })
  } catch (err) { return serverError(res, err) }
})

export default router
