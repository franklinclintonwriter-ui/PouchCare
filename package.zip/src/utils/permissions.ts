import type { SystemRole } from '@/types/enums';

const CEO_ROLES: SystemRole[] = ['CEO', 'CO_MD'];
const OPS_ROLES: SystemRole[] = ['CEO', 'CO_MD', 'OP_MANAGER'];
const MANAGER_ROLES: SystemRole[] = ['CEO', 'CO_MD', 'OP_MANAGER', 'BRANCH_MANAGER', 'HR_MANAGER'];
const HR_ROLES: SystemRole[] = ['CEO', 'CO_MD', 'OP_MANAGER', 'HR_MANAGER'];

export function isCEO(role: SystemRole): boolean {
  return CEO_ROLES.includes(role);
}

export function isOps(role: SystemRole): boolean {
  return OPS_ROLES.includes(role);
}

export function isManager(role: SystemRole): boolean {
  return MANAGER_ROLES.includes(role);
}

export function isHR(role: SystemRole): boolean {
  return HR_ROLES.includes(role);
}

export function hasPermission(role: SystemRole, required: SystemRole[]): boolean {
  return required.includes(role);
}

export const ROLE_LABELS: Record<SystemRole, string> = {
  CEO: 'CEO',
  CO_MD: 'Co-MD',
  OP_MANAGER: 'Operations Manager',
  HR_MANAGER: 'HR Manager',
  BRANCH_MANAGER: 'Branch Manager',
  STAFF: 'Staff',
  INTERN: 'Intern',
};

export const ROLE_COLORS: Record<SystemRole, string> = {
  CEO: 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300',
  CO_MD: 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900/30 dark:text-indigo-300',
  OP_MANAGER: 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300',
  HR_MANAGER: 'bg-teal-100 text-teal-800 dark:bg-teal-900/30 dark:text-teal-300',
  BRANCH_MANAGER: 'bg-cyan-100 text-cyan-800 dark:bg-cyan-900/30 dark:text-cyan-300',
  STAFF: 'bg-gray-100 text-gray-800 dark:bg-gray-700/50 dark:text-gray-300',
  INTERN: 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300',
};
