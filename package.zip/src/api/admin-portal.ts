import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import api from './client';
import type { QueryParams, PaginatedResponse } from '@/types/api';
import type { PortalMember, PortalOrder, CommissionRecord, PayoutRecord } from '@/types/models';

export function usePortalMembers(params?: QueryParams) {
  return useQuery<PaginatedResponse<PortalMember>>({
    queryKey: ['admin-portal-members', params],
    queryFn: async () => {
      const { data } = await api.get('/admin/portal/members', { params });
      return data;
    },
  });
}

export function usePortalMember(id: string) {
  return useQuery<PortalMember>({
    queryKey: ['admin-portal-member', id],
    queryFn: async () => {
      const { data } = await api.get(`/admin/portal/members/${id}`);
      return data;
    },
    enabled: !!id,
  });
}

export function useAdminPortalOrders(params?: QueryParams) {
  return useQuery<PaginatedResponse<PortalOrder>>({
    queryKey: ['admin-portal-orders', params],
    queryFn: async () => {
      const { data } = await api.get('/admin/portal/orders', { params });
      return data;
    },
  });
}

export function useAdminCommissions(params?: QueryParams) {
  return useQuery<PaginatedResponse<CommissionRecord>>({
    queryKey: ['admin-commissions', params],
    queryFn: async () => {
      const { data } = await api.get('/admin/portal/commissions', { params });
      return data;
    },
  });
}

export function useAdminPayouts(params?: QueryParams) {
  return useQuery<PaginatedResponse<PayoutRecord>>({
    queryKey: ['admin-payouts', params],
    queryFn: async () => {
      const { data } = await api.get('/admin/portal/payouts', { params });
      return data;
    },
  });
}

export function useUpdateMemberStatus() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const { data } = await api.put(`/admin/portal/members/${id}/status`, { status });
      return data;
    },
    onSuccess: (_data, { id }) => {
      qc.invalidateQueries({ queryKey: ['admin-portal-member', id] });
      qc.invalidateQueries({ queryKey: ['admin-portal-members'] });
    },
  });
}

export function useUpdateOrderStatus() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, status, deliveryLink }: { id: string; status: string; deliveryLink?: string }) => {
      const { data } = await api.put(`/admin/portal/orders/${id}/status`, { status, deliveryLink });
      return data;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admin-portal-orders'] }),
  });
}

export function useProcessPayout() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, status, transactionId }: { id: string; status: string; transactionId?: string }) => {
      const { data } = await api.put(`/admin/portal/payouts/${id}/process`, { status, transactionId });
      return data;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admin-payouts'] }),
  });
}
