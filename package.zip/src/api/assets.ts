import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import api from './client';
import type { QueryParams, PaginatedResponse } from '@/types/api';
import type { Domain, ServerAsset, WebsiteAsset } from '@/types/models';

export function useDomains(params?: QueryParams) {
  return useQuery<PaginatedResponse<Domain>>({
    queryKey: ['domains', params],
    queryFn: async () => {
      const { data } = await api.get('/assets/domains', { params });
      return Array.isArray(data)
        ? { data, meta: { total: data.length, page: 1, limit: 100, totalPages: 1 } }
        : data;
    },
  });
}

export function useCreateDomain() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: Record<string, unknown>) => api.post('/assets/domains', body),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['domains'] }),
  });
}

export function useUpdateDomain() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, ...body }: Record<string, unknown> & { id: string }) => api.put(`/assets/domains/${id}`, body),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['domains'] }),
  });
}

export function useServers() {
  return useQuery<ServerAsset[]>({
    queryKey: ['servers'],
    queryFn: async () => {
      const { data } = await api.get('/assets/servers');
      return Array.isArray(data) ? data : data.data ?? [];
    },
  });
}

export function useCreateServer() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: Record<string, unknown>) => api.post('/assets/servers', body),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['servers'] }),
  });
}

export function useWebsites(params?: QueryParams) {
  return useQuery<PaginatedResponse<WebsiteAsset>>({
    queryKey: ['websites', params],
    queryFn: async () => {
      const { data } = await api.get('/assets/websites', { params });
      return Array.isArray(data)
        ? { data, meta: { total: data.length, page: 1, limit: 100, totalPages: 1 } }
        : data;
    },
  });
}

export function useCreateWebsite() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: Record<string, unknown>) => api.post('/assets/websites', body),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['websites'] }),
  });
}
