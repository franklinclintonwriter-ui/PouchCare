import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import api from './client';
import type { QueryParams, PaginatedResponse } from '@/types/api';
import type { DailyReport } from '@/types/models';

export function useDailyReports(params?: QueryParams) {
  return useQuery<PaginatedResponse<DailyReport>>({
    queryKey: ['daily-reports', params],
    queryFn: async () => {
      const { data } = await api.get('/reports/daily', { params });
      return data;
    },
  });
}

export function useSubmitReport() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: { tasksCompleted: string; plannedTomorrow: string; blockers?: string; hoursWorked: number; mood?: string }) =>
      api.post('/reports/daily', body),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['daily-reports'] }),
  });
}

export function useReviewReport() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, note }: { id: string; note: string }) => api.put(`/reports/daily/${id}/review`, { note }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['daily-reports'] }),
  });
}
