import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import api from './client';
import type { QueryParams, PaginatedResponse } from '@/types/api';
import type { LeaveRequest } from '@/types/models';

export function useLeaveRequests(params?: QueryParams) {
  return useQuery<PaginatedResponse<LeaveRequest>>({
    queryKey: ['leave', params],
    queryFn: async () => {
      const { data } = await api.get('/leave', { params });
      return data;
    },
  });
}

export function useApplyLeave() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: { leaveType: string; startDate: string; endDate: string; reason?: string }) => api.post('/leave/apply', body),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['leave'] }),
  });
}

export function useApproveLeave() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => api.put(`/leave/${id}/approve`),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['leave'] }),
  });
}

export function useRejectLeave() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, reason }: { id: string; reason?: string }) => api.put(`/leave/${id}/reject`, { reason }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['leave'] }),
  });
}

export function useCancelLeave() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => api.put(`/leave/${id}/cancel`),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['leave'] }),
  });
}
