import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import api from './client';
import type { QueryParams, PaginatedResponse } from '@/types/api';
import type { StaffMember } from '@/types/models';

export function useStaffList(params?: QueryParams) {
  return useQuery<PaginatedResponse<StaffMember>>({
    queryKey: ['staff-list', params],
    queryFn: async () => {
      const { data } = await api.get('/staff/members', { params });
      return data;
    },
  });
}

export function useStaffMember(id: string) {
  return useQuery<StaffMember>({
    queryKey: ['staff-member', id],
    queryFn: async () => {
      const { data } = await api.get(`/staff/members/${id}`);
      return data;
    },
    enabled: !!id,
  });
}

export function useCreateStaff() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: Record<string, unknown>) => api.post('/staff/members', body),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['staff-list'] }),
  });
}

export function useUpdateStaff() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, ...body }: Record<string, unknown> & { id: string }) => api.put(`/staff/members/${id}`, body),
    onSuccess: (_, v) => { qc.invalidateQueries({ queryKey: ['staff-list'] }); qc.invalidateQueries({ queryKey: ['staff-member', v.id] }); },
  });
}

export function useRateStaff() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, rating, note }: { id: string; rating: number; note?: string }) => api.post(`/staff/members/${id}/rate`, { rating, note }),
    onSuccess: (_, v) => { qc.invalidateQueries({ queryKey: ['staff-list'] }); qc.invalidateQueries({ queryKey: ['staff-member', v.id] }); },
  });
}
