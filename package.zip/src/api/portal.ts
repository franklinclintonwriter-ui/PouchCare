import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import api from './client';
import type { QueryParams, PaginatedResponse } from '@/types/api';
import type { PortalOrder, WalletTransaction, Referral, CommissionRecord, PayoutRecord } from '@/types/models';

export function usePortalOrders(params?: QueryParams) {
  return useQuery<PaginatedResponse<PortalOrder>>({
    queryKey: ['portal-orders', params],
    queryFn: async () => {
      const { data } = await api.get('/portal/orders', { params });
      return data;
    },
  });
}

export function usePortalOrder(id: string) {
  return useQuery<PortalOrder>({
    queryKey: ['portal-order', id],
    queryFn: async () => {
      const { data } = await api.get(`/portal/orders/${id}`);
      return data;
    },
    enabled: !!id,
  });
}

export function usePlaceOrder() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: { service: string; quantity?: number; requirements?: string }) =>
      api.post('/portal/orders', body),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['portal-orders'] }); qc.invalidateQueries({ queryKey: ['wallet-transactions'] }); },
  });
}

export function useRequestRevision() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, note }: { id: string; note: string }) => api.post(`/portal/orders/${id}/revision`, { note }),
    onSuccess: (_, v) => { qc.invalidateQueries({ queryKey: ['portal-orders'] }); qc.invalidateQueries({ queryKey: ['portal-order', v.id] }); },
  });
}

export function useWalletTransactions() {
  return useQuery<WalletTransaction[]>({
    queryKey: ['wallet-transactions'],
    queryFn: async () => {
      const { data } = await api.get('/portal/wallet/transactions');
      return Array.isArray(data) ? data : data.data ?? [];
    },
  });
}

export function useDeposit() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: { amount: number; paymentMethod?: string; proofUrl?: string }) =>
      api.post('/portal/wallet/deposit', body),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['wallet-transactions'] }); qc.invalidateQueries({ queryKey: ['portal', 'me'] }); },
  });
}

export function useReferrals() {
  return useQuery<Referral[]>({
    queryKey: ['referrals'],
    queryFn: async () => {
      const { data } = await api.get('/portal/referrals');
      return Array.isArray(data) ? data : data.data ?? [];
    },
  });
}

export function useCommissions(params?: QueryParams) {
  return useQuery<PaginatedResponse<CommissionRecord>>({
    queryKey: ['commissions', params],
    queryFn: async () => {
      const { data } = await api.get('/portal/commissions', { params });
      return data;
    },
  });
}

export function useRequestPayout() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: { amount: number; paymentMethod: string; paymentDetails?: string }) =>
      api.post('/portal/commissions/payout-request', body),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['commissions'] }); qc.invalidateQueries({ queryKey: ['payouts'] }); },
  });
}

export function usePayoutsData(params?: QueryParams) {
  return useQuery<PaginatedResponse<PayoutRecord>>({
    queryKey: ['payouts', params],
    queryFn: async () => {
      const { data } = await api.get('/portal/commissions/payouts', { params });
      return data;
    },
  });
}
