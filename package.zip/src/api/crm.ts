import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import api from './client';
import type { QueryParams, PaginatedResponse } from '@/types/api';
import type { Lead, SalesOrder } from '@/types/models';

export function useLeads(params?: QueryParams) {
  return useQuery<PaginatedResponse<Lead>>({
    queryKey: ['leads', params],
    queryFn: async () => {
      const { data } = await api.get('/crm/leads', { params });
      return data;
    },
  });
}

export function useLead(id: string) {
  return useQuery<Lead>({
    queryKey: ['lead', id],
    queryFn: async () => {
      const { data } = await api.get(`/crm/leads/${id}`);
      return data;
    },
    enabled: !!id,
  });
}

export function useLeadsByStage() {
  return useQuery<Record<string, Lead[]>>({
    queryKey: ['leads-by-stage'],
    queryFn: async () => {
      const { data } = await api.get('/crm/leads', { params: { limit: 200 } });
      const list: Lead[] = data.data ?? data;
      const grouped: Record<string, Lead[]> = {};
      list.forEach(l => { (grouped[l.stage] ??= []).push(l); });
      return grouped;
    },
  });
}

export function useCreateLead() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: Record<string, unknown>) => api.post('/crm/leads', body),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['leads'] }); qc.invalidateQueries({ queryKey: ['leads-by-stage'] }); },
  });
}

export function useUpdateLead() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, ...body }: Record<string, unknown> & { id: string }) => api.put(`/crm/leads/${id}`, body),
    onSuccess: (_, v) => { qc.invalidateQueries({ queryKey: ['leads'] }); qc.invalidateQueries({ queryKey: ['lead', v.id] }); qc.invalidateQueries({ queryKey: ['leads-by-stage'] }); },
  });
}

export function useDeleteLead() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => api.delete(`/crm/leads/${id}`),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['leads'] }); qc.invalidateQueries({ queryKey: ['leads-by-stage'] }); },
  });
}

export function useSalesOrders(params?: QueryParams) {
  return useQuery<PaginatedResponse<SalesOrder>>({
    queryKey: ['sales-orders', params],
    queryFn: async () => {
      const { data } = await api.get('/crm/orders', { params });
      return data;
    },
  });
}

export function useCreateSalesOrder() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: Record<string, unknown>) => api.post('/crm/orders', body),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['sales-orders'] }),
  });
}

export function useUpdateSalesOrder() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, ...body }: Record<string, unknown> & { id: string }) => api.put(`/crm/orders/${id}`, body),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['sales-orders'] }),
  });
}
