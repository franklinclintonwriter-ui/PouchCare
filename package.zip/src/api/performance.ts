import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import api from './client';
import type { PerformanceReview } from '@/types/models';

export function usePerformanceReviews(period?: string) {
  return useQuery<PerformanceReview[]>({
    queryKey: ['performance', period],
    queryFn: async () => {
      const { data } = await api.get('/performance', { params: period ? { period } : undefined });
      return data;
    },
  });
}

export function useCreatePerformanceReview() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: Record<string, unknown>) => api.post('/performance', body),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['performance'] }),
  });
}
