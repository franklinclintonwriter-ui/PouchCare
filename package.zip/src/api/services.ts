import { useQuery } from '@tanstack/react-query';
import api from './client';
import type { Service, BacklinkPackage } from '@/types/models';

export function useServices(category?: string) {
  return useQuery<Service[]>({
    queryKey: ['services', category],
    queryFn: async () => {
      const { data } = await api.get('/services', { params: category ? { category } : undefined });
      return Array.isArray(data) ? data : data.data ?? [];
    },
  });
}

export function useBacklinkPackages() {
  return useQuery<BacklinkPackage[]>({
    queryKey: ['backlink-packages'],
    queryFn: async () => {
      const { data } = await api.get('/backlink-packages');
      return Array.isArray(data) ? data : data.data ?? [];
    },
  });
}
