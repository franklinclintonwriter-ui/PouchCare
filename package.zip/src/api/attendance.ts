import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import api from './client';
import type { QueryParams, PaginatedResponse } from '@/types/api';
import type { AttendanceRecord } from '@/types/models';

export function useAttendance(params?: QueryParams) {
  return useQuery<PaginatedResponse<AttendanceRecord>>({
    queryKey: ['attendance', params],
    queryFn: async () => {
      const { data } = await api.get('/attendance', { params });
      return data;
    },
  });
}

export function useMyAttendance() {
  return useQuery<AttendanceRecord[]>({
    queryKey: ['my-attendance'],
    queryFn: async () => {
      const { data } = await api.get('/attendance', { params: { limit: 60 } });
      return data.data ?? data;
    },
  });
}

export function useTeamAttendance(date?: string) {
  const d = date || new Date().toISOString().split('T')[0];
  return useQuery<AttendanceRecord[]>({
    queryKey: ['team-attendance', d],
    queryFn: async () => {
      const { data } = await api.get('/attendance', { params: { date: d, limit: 100 } });
      return data.data ?? data;
    },
  });
}

export function useTodayAttendance() {
  return useQuery({
    queryKey: ['attendance-today'],
    queryFn: async () => {
      const { data } = await api.get('/attendance/today');
      return data;
    },
  });
}

export function useCheckIn() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body?: Record<string, unknown>) => api.post('/attendance/checkin', body),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['attendance'] }); qc.invalidateQueries({ queryKey: ['my-attendance'] }); qc.invalidateQueries({ queryKey: ['attendance-today'] }); },
  });
}

export function useCheckOut() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body?: Record<string, unknown>) => api.post('/attendance/checkout', body),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['attendance'] }); qc.invalidateQueries({ queryKey: ['my-attendance'] }); qc.invalidateQueries({ queryKey: ['attendance-today'] }); },
  });
}
