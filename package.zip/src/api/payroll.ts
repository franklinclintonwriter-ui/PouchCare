import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import api from './client';
import type { PaginatedResponse } from '@/types/api';
import type { PayrollEntry } from '@/types/models';

export function usePayroll(month?: number, year?: number) {
  return useQuery<PaginatedResponse<PayrollEntry>>({
    queryKey: ['payroll', month, year],
    queryFn: async () => {
      const { data } = await api.get('/payroll', { params: { month, year, limit: 100 } });
      return data;
    },
  });
}

export function useCreatePayroll() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: Record<string, unknown>) => api.post('/payroll', body),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['payroll'] }),
  });
}

export function useMarkPayrollPaid() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => api.put(`/payroll/${id}/mark-paid`),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['payroll'] }),
  });
}
