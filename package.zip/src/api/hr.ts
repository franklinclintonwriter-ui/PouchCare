import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import api from './client';
import type { QueryParams, PaginatedResponse } from '@/types/api';
import type { Position, JobApplication } from '@/types/models';

export function usePositions(params?: QueryParams) {
  return useQuery<PaginatedResponse<Position>>({
    queryKey: ['positions', params],
    queryFn: async () => {
      const { data } = await api.get('/hr/positions', { params });
      return data;
    },
  });
}

export function useCreatePosition() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: Record<string, unknown>) => api.post('/hr/positions', body),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['positions'] }),
  });
}

export function useUpdatePosition() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, ...body }: Record<string, unknown> & { id: string }) => api.put(`/hr/positions/${id}`, body),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['positions'] }),
  });
}

export function useApplications(params?: QueryParams) {
  return useQuery<PaginatedResponse<JobApplication>>({
    queryKey: ['applications', params],
    queryFn: async () => {
      const { data } = await api.get('/hr/applications', { params });
      return data;
    },
  });
}

export function useCreateApplication() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: Record<string, unknown>) => api.post('/hr/applications', body),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['applications'] }),
  });
}

export function useUpdateApplication() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, ...body }: Record<string, unknown> & { id: string }) => api.put(`/hr/applications/${id}`, body),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['applications'] }),
  });
}
