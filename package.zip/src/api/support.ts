import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import api from './client';
import type { QueryParams, PaginatedResponse } from '@/types/api';
import type { Ticket } from '@/types/models';

export function useTickets(params?: QueryParams) {
  return useQuery<PaginatedResponse<Ticket>>({
    queryKey: ['tickets', params],
    queryFn: async () => {
      const { data } = await api.get('/support/tickets', { params });
      return data;
    },
  });
}

export function useTicket(id: string) {
  return useQuery<Ticket>({
    queryKey: ['ticket', id],
    queryFn: async () => {
      const { data } = await api.get(`/support/tickets/${id}`);
      return data;
    },
    enabled: !!id,
  });
}

export function useCreateTicket() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: { subject: string; message: string; priority?: string }) => api.post('/support/tickets', body),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['tickets'] }),
  });
}

export function useReplyToTicket() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ ticketId, content }: { ticketId: string; content: string }) => api.post(`/support/tickets/${ticketId}/reply`, { content }),
    onSuccess: (_, v) => qc.invalidateQueries({ queryKey: ['ticket', v.ticketId] }),
  });
}

export function useUpdateTicket() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, ...body }: Record<string, unknown> & { id: string }) => api.put(`/support/tickets/${id}`, body),
    onSuccess: (_, v) => { qc.invalidateQueries({ queryKey: ['tickets'] }); qc.invalidateQueries({ queryKey: ['ticket', v.id] }); },
  });
}
