import { useMemo } from 'react';
import { useAuthStore } from '@/store/authStore';
import type { SystemRole } from '@/types/enums';
import type { StaffUser } from '@/types/auth';
import { isCEO, isOps, isManager, isHR } from '@/utils/permissions';

export function usePermission() {
  const user = useAuthStore((s) => s.user);
  const userType = useAuthStore((s) => s.userType);

  return useMemo(() => {
    if (userType !== 'staff' || !user) {
      return {
        role: null as SystemRole | null,
        isCEO: false,
        isOps: false,
        isManager: false,
        isHR: false,
        isStaff: false,
        isPortal: userType === 'portal',
        hasRole: (_roles: SystemRole[]) => false,
      };
    }

    const role = (user as StaffUser).systemRole;

    return {
      role,
      isCEO: isCEO(role),
      isOps: isOps(role),
      isManager: isManager(role),
      isHR: isHR(role),
      isStaff: true,
      isPortal: false,
      hasRole: (roles: SystemRole[]) => roles.includes(role),
    };
  }, [user, userType]);
}
