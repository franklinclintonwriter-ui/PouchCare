import { useState } from 'react';
import { LifeBuoy, Plus } from 'lucide-react';
import { useHeaderConfig } from '@/hooks/useHeaderConfig';
import { PageTransition } from '@/components/ui/PageTransition';
import { DataTable, type Column } from '@/components/ui/DataTable';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { Modal } from '@/components/ui/Modal';
import { Input } from '@/components/ui/Input';
import { Textarea } from '@/components/ui/Textarea';
import { Button } from '@/components/ui/Button';

interface SupportTicket {
  id: string;
  subject: string;
  status: string;
  lastReply: string;
  created: string;
}

// Empty by default to show empty state
const tickets: SupportTicket[] = [];

export default function PortalSupport() {
  const [showNew, setShowNew] = useState(false);

  useHeaderConfig({
    title: 'Support',
    breadcrumbs: [
      { label: 'Dashboard', href: '/portal' },
      { label: 'Support' },
    ],
    actions: [
      { type: 'button', label: 'New Ticket', icon: Plus, onClick: () => setShowNew(true) },
    ],
  });

  const columns: Column<SupportTicket>[] = [
    { key: 'subject', label: 'Subject', render: (r) => <span className="text-sm font-medium">{r.subject}</span> },
    { key: 'status', label: 'Status', render: (r) => <StatusBadge status={r.status} size="sm" /> },
    { key: 'lastReply', label: 'Last Reply', render: (r) => <span className="text-xs text-gray-500">{r.lastReply}</span> },
    { key: 'created', label: 'Created', render: (r) => <span className="text-xs text-gray-500">{r.created}</span> },
  ];

  return (
    <PageTransition>
      <div className="space-y-4">
        <DataTable
          columns={columns}
          data={tickets}
          emptyIcon={<LifeBuoy />}
          emptyTitle="No tickets"
          emptyDescription="You haven't submitted any support tickets yet."
        />

        <Modal isOpen={showNew} onClose={() => setShowNew(false)} title="New Support Ticket">
          <div className="space-y-4">
            <Input label="Subject" placeholder="Brief description of your issue" />
            <Textarea label="Message" placeholder="Describe your issue in detail..." />
            <div className="flex justify-end gap-2">
              <Button variant="outline" size="sm" onClick={() => setShowNew(false)}>Cancel</Button>
              <Button size="sm" onClick={() => setShowNew(false)}>Submit</Button>
            </div>
          </div>
        </Modal>
      </div>
    </PageTransition>
  );
}
