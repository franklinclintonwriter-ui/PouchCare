import { useHeaderConfig } from '@/hooks/useHeaderConfig';
import { useAuthStore } from '@/store/authStore';
import { useWalletTransactions } from '@/api/portal';
import { formatCurrency } from '@/mocks/generators';
import { PageTransition } from '@/components/ui/PageTransition';
import { Badge } from '@/components/ui/Badge';
import { DataTable, type Column } from '@/components/ui/DataTable';
import { WalletCard } from '@/components/shared/WalletCard';
import type { PortalUser } from '@/types/auth';
import type { WalletTransaction } from '@/types/models';

const TX_BADGE_VARIANT: Record<string, 'success' | 'danger' | 'primary' | 'warning' | 'info' | 'default'> = {
  DEPOSIT: 'success',
  ORDER_PAYMENT: 'danger',
  COMMISSION_CREDIT: 'primary',
  REFUND: 'info',
  PAYOUT: 'warning',
  ADJUSTMENT: 'default',
};

export default function Wallet() {
  const { user } = useAuthStore();
  const portalUser = user as PortalUser;

  useHeaderConfig({
    title: 'Wallet',
    breadcrumbs: [
      { label: 'Dashboard', href: '/portal' },
      { label: 'Wallet' },
    ],
  });

  const { data: transactions, isLoading } = useWalletTransactions();

  const columns: Column<WalletTransaction>[] = [
    { key: 'createdAt', label: 'Date', render: (r) => <span className="text-xs text-gray-500">{r.createdAt}</span> },
    {
      key: 'type',
      label: 'Type',
      render: (r) => (
        <Badge variant={TX_BADGE_VARIANT[r.type] ?? 'default'} size="sm">
          {r.type.replace(/_/g, ' ')}
        </Badge>
      ),
    },
    { key: 'description', label: 'Description', render: (r) => <span className="text-xs capitalize">{r.description}</span> },
    {
      key: 'amount',
      label: 'Amount',
      align: 'right',
      render: (r) => (
        <span className={r.amount >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400'}>
          {r.amount >= 0 ? '+' : ''}{formatCurrency(r.amount)}
        </span>
      ),
    },
    {
      key: 'balanceAfter',
      label: 'Balance',
      align: 'right',
      render: (r) => <span className="text-xs font-medium">{formatCurrency(r.balanceAfter)}</span>,
    },
  ];

  return (
    <PageTransition>
      <div className="space-y-5">
        <WalletCard
          balance={portalUser?.walletBalance ?? 0}
          pendingCommissions={150}
          totalEarned={2400}
          onDeposit={() => {}}
          onWithdraw={() => {}}
        />

        <DataTable
          columns={columns}
          data={transactions ?? []}
          isLoading={isLoading}
          emptyTitle="No transactions"
          emptyDescription="Your wallet transactions will appear here."
        />
      </div>
    </PageTransition>
  );
}
