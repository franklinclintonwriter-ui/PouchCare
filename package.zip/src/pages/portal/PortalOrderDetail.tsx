import { useState } from 'react';
import { useParams } from 'react-router-dom';
import { useHeaderConfig } from '@/hooks/useHeaderConfig';
import { usePortalOrder } from '@/api/portal';
import { formatCurrency } from '@/mocks/generators';
import { PageTransition } from '@/components/ui/PageTransition';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/Card';
import { Tabs } from '@/components/ui/Tabs';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { Skeleton } from '@/components/ui/Skeleton';
import { OrderTimeline } from '@/components/shared/OrderTimeline';
import { MessageSquare } from 'lucide-react';

export default function PortalOrderDetail() {
  const { id } = useParams<{ id: string }>();
  const { data: order, isLoading } = usePortalOrder(id!);
  const [tab, setTab] = useState('details');

  useHeaderConfig({
    title: order?.number ?? 'Order',
    breadcrumbs: [
      { label: 'Dashboard', href: '/portal' },
      { label: 'Orders', href: '/portal/orders' },
      { label: order?.number ?? '...' },
    ],
  });

  if (isLoading) {
    return (
      <PageTransition>
        <div className="space-y-4">
          <Skeleton className="h-16 w-full rounded-xl" />
          <Skeleton className="h-48 w-full rounded-xl" />
        </div>
      </PageTransition>
    );
  }

  if (!order) {
    return (
      <PageTransition>
        <Card>
          <p className="text-sm text-gray-500">Order not found.</p>
        </Card>
      </PageTransition>
    );
  }

  return (
    <PageTransition>
      <div className="space-y-4">
        {/* Timeline */}
        <Card>
          <OrderTimeline currentStatus={order.status} />
        </Card>

        {/* Info Card */}
        <Card>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            <InfoItem label="Service" value={order.serviceName} />
            <InfoItem label="Amount" value={formatCurrency(order.amount)} />
            <InfoItem label="Status">
              <StatusBadge status={order.status} />
            </InfoItem>
            <InfoItem label="Placed" value={order.placedDate} />
            <InfoItem label="Delivery" value={order.deliveryDate ?? 'Pending'} />
            <InfoItem label="Assigned Staff" value={order.assignedStaff ?? 'Unassigned'} />
          </div>
        </Card>

        {/* Tabs */}
        <Tabs
          tabs={[
            { label: 'Details', value: 'details' },
            { label: 'Messages', value: 'messages' },
          ]}
          value={tab}
          onChange={setTab}
        />

        {tab === 'details' && (
          <Card>
            <CardHeader>
              <CardTitle>Specifications</CardTitle>
            </CardHeader>
            <CardContent>
              {Object.keys(order.specifications).length > 0 ? (
                <div className="divide-y divide-gray-100 dark:divide-gray-700 rounded-lg border border-gray-200 dark:border-gray-700">
                  {Object.entries(order.specifications).map(([key, val]) => (
                    <div key={key} className="flex items-center justify-between px-3 py-2">
                      <span className="text-xs capitalize text-gray-500 dark:text-gray-400">{key}</span>
                      <span className="text-xs font-medium text-gray-900 dark:text-gray-100 max-w-[60%] truncate text-right">{val}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-gray-400">No specifications provided.</p>
              )}
            </CardContent>
          </Card>
        )}

        {tab === 'messages' && (
          <Card>
            <div className="flex flex-col items-center gap-2 py-8 text-gray-400 dark:text-gray-500">
              <MessageSquare className="h-8 w-8" />
              <p className="text-sm">No messages yet</p>
              <p className="text-xs">Messages with support will appear here.</p>
            </div>
          </Card>
        )}
      </div>
    </PageTransition>
  );
}

function InfoItem({ label, value, children }: { label: string; value?: string; children?: React.ReactNode }) {
  return (
    <div>
      <p className="text-[11px] text-gray-500 dark:text-gray-400">{label}</p>
      {children ?? <p className="mt-0.5 text-sm font-medium text-gray-900 dark:text-gray-100">{value}</p>}
    </div>
  );
}
