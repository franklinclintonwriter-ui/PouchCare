import { useMemo } from 'react';
import { Link } from 'lucide-react';
import { useHeaderConfig } from '@/hooks/useHeaderConfig';
import { useBacklinkPackages } from '@/api/services';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { PageTransition } from '@/components/ui/PageTransition';
import { Skeleton } from '@/components/ui/Skeleton';
import { formatCurrency } from '@/mocks/generators';

export default function BacklinkPackages() {
  const { data: packages, isLoading } = useBacklinkPackages();

  const headerConfig = useMemo(() => ({
    title: 'Backlink Packages',
    breadcrumbs: [
      { label: 'Services', href: '/services' },
      { label: 'Backlink Packages', icon: Link },
    ],
    actions: [],
  }), []);
  useHeaderConfig(headerConfig);

  return (
    <PageTransition>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {isLoading
          ? Array.from({ length: 4 }).map((_, i) => (
              <Card key={i}>
                <div className="space-y-4 text-center">
                  <Skeleton className="mx-auto h-5 w-20 rounded" />
                  <Skeleton className="mx-auto h-8 w-24 rounded" />
                  <div className="space-y-2">
                    <Skeleton className="h-3 w-full rounded" />
                    <Skeleton className="h-3 w-full rounded" />
                    <Skeleton className="h-3 w-full rounded" />
                  </div>
                </div>
              </Card>
            ))
          : packages?.map((pkg) => (
              <Card
                key={pkg.id}
                className={
                  pkg.isPopular
                    ? 'relative border-primary-300 ring-2 ring-primary-500/20 dark:border-primary-600'
                    : ''
                }
              >
                {pkg.isPopular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <Badge variant="primary">Popular</Badge>
                  </div>
                )}

                <div className="text-center">
                  <p className="text-sm font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400">
                    {pkg.name}
                  </p>

                  <p className="mt-3 text-3xl font-bold text-gray-900 dark:text-gray-100">
                    {formatCurrency(pkg.price)}
                  </p>

                  <div className="mt-5 space-y-3 text-sm text-gray-600 dark:text-gray-400">
                    <div className="flex items-center justify-between border-b border-gray-100 pb-2 dark:border-gray-700/40">
                      <span>DA Range</span>
                      <span className="font-medium text-gray-900 dark:text-gray-100">{pkg.daRange}</span>
                    </div>
                    <div className="flex items-center justify-between border-b border-gray-100 pb-2 dark:border-gray-700/40">
                      <span>Link Type</span>
                      <span className="font-medium text-gray-900 dark:text-gray-100">{pkg.linkType}</span>
                    </div>
                    <div className="flex items-center justify-between border-b border-gray-100 pb-2 dark:border-gray-700/40">
                      <span>Quantity</span>
                      <span className="font-medium text-gray-900 dark:text-gray-100">{pkg.quantity} links</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Turnaround</span>
                      <span className="font-medium text-gray-900 dark:text-gray-100">{pkg.turnaround}</span>
                    </div>
                  </div>

                  <Button variant={pkg.isPopular ? 'primary' : 'outline'} fullWidth className="mt-5">
                    Select Plan
                  </Button>
                </div>
              </Card>
            ))}
      </div>
    </PageTransition>
  );
}
