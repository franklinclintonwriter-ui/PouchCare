import { useState, useMemo } from 'react';
import { useHeaderConfig } from '@/hooks/useHeaderConfig';
import { useInvoices } from '@/api/finance';
import { PageTransition } from '@/components/ui/PageTransition';
import { StatsRow } from '@/components/shared/StatsRow';
import { DataTable, type Column } from '@/components/ui/DataTable';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { formatCurrency } from '@/mocks/generators';
import { DollarSign, FileText, CheckCircle, AlertTriangle, CircleDot } from 'lucide-react';
import type { Invoice } from '@/types/models';

export default function InvoiceList() {
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [page, setPage] = useState(1);

  const { data, isLoading } = useInvoices({ q: search, status, page, limit: 20 });
  const invoices = data?.data ?? [];
  const meta = data?.meta;

  // Stats from all invoices (unfiltered query for totals)
  const { data: allData } = useInvoices({});
  const allInvoices = allData?.data ?? [];

  const stats = useMemo(() => {
    const total = allInvoices.reduce((s, i) => s + i.total, 0);
    const paid = allInvoices.filter(i => i.status === 'PAID').reduce((s, i) => s + i.total, 0);
    const unpaid = allInvoices.filter(i => i.status === 'UNPAID' || i.status === 'PARTIAL').reduce((s, i) => s + i.total - i.paidAmount, 0);
    const overdue = allInvoices.filter(i => i.status === 'OVERDUE').length;
    return { total, paid, unpaid, overdue };
  }, [allInvoices]);

  useHeaderConfig({
    title: 'Invoices',
    breadcrumbs: [{ label: 'Finance' }, { label: 'Invoices' }],
    actions: [
      { type: 'search', placeholder: 'Search invoices...', value: search, onChange: setSearch },
      {
        type: 'filter', label: 'Status', icon: CircleDot, value: status, onChange: setStatus,
        options: [
          { label: 'All Statuses', value: '' },
          { label: 'Paid', value: 'PAID' },
          { label: 'Unpaid', value: 'UNPAID' },
          { label: 'Partial', value: 'PARTIAL' },
          { label: 'Overdue', value: 'OVERDUE' },
          { label: 'Refunded', value: 'REFUNDED' },
        ],
      },
    ],
  });

  const columns: Column<Invoice>[] = [
    { key: 'number', label: 'Invoice #', sticky: true, render: (row) => (
      <span className="font-semibold text-gray-900 dark:text-gray-100">{row.number}</span>
    )},
    { key: 'clientName', label: 'Client' },
    { key: 'total', label: 'Amount', align: 'right', render: (row) => (
      <span className="font-medium">{formatCurrency(row.total)}</span>
    )},
    { key: 'status', label: 'Status', render: (row) => <StatusBadge status={row.status} /> },
    { key: 'issueDate', label: 'Issue Date' },
    { key: 'dueDate', label: 'Due Date' },
  ];

  return (
    <PageTransition className="space-y-6">
      <StatsRow
        loading={isLoading}
        items={[
          { title: 'Total Invoiced', value: formatCurrency(stats.total), icon: <FileText className="h-4 w-4" />, iconBg: 'bg-blue-100 dark:bg-blue-900/30' },
          { title: 'Paid', value: formatCurrency(stats.paid), icon: <CheckCircle className="h-4 w-4" />, iconBg: 'bg-emerald-100 dark:bg-emerald-900/30' },
          { title: 'Unpaid', value: formatCurrency(stats.unpaid), icon: <DollarSign className="h-4 w-4" />, iconBg: 'bg-amber-100 dark:bg-amber-900/30' },
          { title: 'Overdue', value: stats.overdue, icon: <AlertTriangle className="h-4 w-4" />, iconBg: 'bg-red-100 dark:bg-red-900/30' },
        ]}
      />

      <DataTable<Invoice>
        columns={columns}
        data={invoices}
        isLoading={isLoading}
        pagination={meta}
        onPageChange={setPage}
        getRowId={(row) => row.id}
      />
    </PageTransition>
  );
}
